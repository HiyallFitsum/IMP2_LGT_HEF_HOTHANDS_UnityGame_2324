using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillBox : MonoBehaviour
{
    
    [SerializeField] CheckPoint checkPointComponent;
    void Update()
    {
    }
    void OnCollisionEnter(Collision other){
        if(other.gameObject.CompareTag("Player")){
            checkPointComponent.playerDead= true;
        }
        else if(!other.gameObject.CompareTag("Fist")){
            Destroy(other.gameObject);
        }
        Debug.Log("VoidColliding");
    }
}
