using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class Portal : MonoBehaviour
{
    [SerializeField] int NextLevel;
    [SerializeField] int enemyCount;
    private RaycastHit[] enemiesDetected;
    [SerializeField] int openPortalEnemyMax = 0;
    [SerializeField] TextMeshProUGUI EnemyCountText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        enemyCount=GameObject.FindGameObjectsWithTag("Enemy").Length;
        //Debug.Log("Enemy Count: " + enemyCount);
        EnemyCountText.text = enemyCount.ToString();
    }
    void OnCollisionEnter(Collision other){
        Debug.Log(other.gameObject);
        if (other.gameObject.CompareTag("Player") && enemyCount <= openPortalEnemyMax){
            SceneManager.LoadScene(NextLevel);
            Debug.Log(other.gameObject);
        }
    }
}
