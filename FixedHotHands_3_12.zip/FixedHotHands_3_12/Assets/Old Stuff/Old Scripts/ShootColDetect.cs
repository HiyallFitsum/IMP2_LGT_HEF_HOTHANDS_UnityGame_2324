using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootColDetect : MonoBehaviour
{
    public GameObject ThisShootFist;
    public Rigidbody ThisShootFistRB;
    float reloadCounter;
    //[SerializeField] Fist rFist
    public float reloadTime;//time bettween fist hitting something and being able to reload
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        /*if(reloadCounter>=0){
            if(ThisShootFist==LShootFist)
           // Camerafist.LCanReload=true;
            else if(ThisShootFist==RShootFist)
            //Camerafist.RCanReload=true;
        }
        else
        reloadCounter-=Time.deltaTime;
        
    }
    void OnCollisionEnter(Collision other){
        ThisShootFistRB.useGravity = true;
        reloadCounter=reloadTime;
        */
    }
}
