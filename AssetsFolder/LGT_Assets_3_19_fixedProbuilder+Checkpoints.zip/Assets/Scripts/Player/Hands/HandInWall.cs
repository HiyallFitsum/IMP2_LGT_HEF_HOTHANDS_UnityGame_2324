using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class HandInWall : MonoBehaviour
{
    [SerializeField] bool fistIsTouching;
    [SerializeField] Fist FistScript;//this has to be the script on the corresponding shoot fist
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (fistIsTouching)
            FistScript.HandisClipping=true;
        else
            FistScript.HandisClipping=false;
    }
    void OnTriggerStay(Collider other){
        //Debug.Log("hand is Colliding with: " + other.gameObject.name);
        if (!other.CompareTag("Enemy"))
        fistIsTouching=true;
    }
    void OnTriggerExit(Collider other){
        if (!other.CompareTag("Enemy"))
        fistIsTouching=false;
    }
    void OnCollisionStay(Collision other){
        //Debug.Log("hand is Colliding with: " + other.gameObject.name);
        if (!other.gameObject.CompareTag("Enemy"))
        fistIsTouching=true;
    }
    
    void OnCollisionExit(Collision other){
        if (!other.gameObject.CompareTag("Enemy"))
        fistIsTouching=false;
    }
}
