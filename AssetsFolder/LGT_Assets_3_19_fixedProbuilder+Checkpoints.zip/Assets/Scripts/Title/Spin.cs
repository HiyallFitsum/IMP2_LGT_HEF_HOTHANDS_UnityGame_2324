using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spin : MonoBehaviour
{
    [SerializeField] float rotateSpeed=120f;

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector3(0.66f,0.1f,1f)*Time.deltaTime*rotateSpeed);
    }
}
