using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camerafist : MonoBehaviour
{
    public bool LReloaded = true;
    public bool RReloaded = true;
    [Header("CameraFists")]
    public GameObject LCamFist;
    public GameObject RCamFist;
    [SerializeField] MeshRenderer LCamFistRenderer;
    [SerializeField] MeshRenderer RCamFistRenderer;
    [Header("ShootingFists")]
    public GameObject LShootFist;
    public GameObject RShootFist;
    [SerializeField] Vector3 LTempShootFistPos = new Vector3(1000f,-100f,1000f);
    [SerializeField] Vector3 RTempShootFistPos = new Vector3(1000f,-100f,-1000f);
    
    
    public Rigidbody LShootFistRB;
    public Rigidbody RShootFistRB;
    public bool LCanReload;
    public bool RCanReload;
    public float speed=8;
    // Start is called before the first frame update
    void Start()
    {
        Physics.IgnoreCollision(LShootFist.GetComponent<Collider>(), RShootFist.GetComponent<Collider>());
        Physics.IgnoreCollision(RShootFist.GetComponent<Collider>(), LShootFist.GetComponent<Collider>());
        LShootFist.transform.position = LTempShootFistPos;
        RShootFist.transform.position = RTempShootFistPos;
        
    }
    /*
    // Update is called once per frame
    void Update()
    {
        
        if(Input.GetAxis("Fire1")!=0&&LReloaded){
            ReplaceLfist();
            RaycastHit hit;
           Physics.Raycast(LShootFist.transform.position,  LShootFist.transform.forward*distance, out hit);
            if(hit.collider != null)
            {
                LShootFist.transform.forward = hit.point - LShootFist.transform.position;
            }
            LShootFistRB.velocity= new Vector3(0f,0f,0f);
            LShootFistRB.AddForce(LShootFist.transform.forward * speed,ForceMode.Impulse);
            LreloadCounter = reloadTime;
            LReloaded=false;
        }
        if(Input.GetAxis("Fire2")!=0&&RReloaded){
            ReplaceRfist();
            RaycastHit hit;
           Physics.Raycast(RShootFist.transform.position,  RShootFist.transform.forward*distance, out hit);
            if(hit.collider != null)
            {
                RShootFist.transform.forward = hit.point - RShootFist.transform.position;
            }
            RShootFistRB.velocity= new Vector3(0f,0f,0f);
            RShootFistRB.AddForce(RShootFist.transform.forward * speed,ForceMode.Impulse);
            RreloadCounter = reloadTime;
            RReloaded=false;

        }
        if(LReloaded==false&&LCanReload)
        {
            ReloadLfist();
            LReloaded=true;
            //LShootFist.isActiveInHierarchy=
        }
        if(Input.GetKeyDown("e")&&RReloaded==false&&RreloadCounter<=0)
        {
            ReloadRfist();
            RReloaded=true;

        }
    }

    //void ReplaceFist(Gam)
    void ReplaceLfist(){//
        LCamFistRenderer.enabled = false;
        LShootFist.transform.position= LCamFist.transform.position;
        LShootFist.transform.rotation= LCamFist.transform.rotation;
        LShootFistRB.angularVelocity= new Vector3(0f,0f,0f);
    }
    ///Funtion ReplaceRFist
    ///Parameters: none
    ///Intended action description
    void ReplaceRfist(){
        RCamFistRenderer.enabled = false;
        RShootFist.transform.position= RCamFist.transform.position;
        RShootFist.transform.rotation= RCamFist.transform.rotation;
        RShootFistRB.angularVelocity= new Vector3(0f,0f,0f);
    }
    void ReloadLfist(){ 
        LCamFistRenderer.enabled = true;
        LShootFist.transform.position = LTempShootFistPos;
        LShootFistRB.velocity= new Vector3(0f,0f,0f);
        LShootFistRB.angularVelocity= new Vector3(0f,0f,0f);
        LShootFist.transform.rotation= new Quaternion(0f,0f,0f,1);
    }
    void ReloadRfist(){
        RCamFistRenderer.enabled = true;
        RShootFist.transform.position = RTempShootFistPos;
        RShootFistRB.velocity= new Vector3(0f,0f,0f);
        RShootFistRB.angularVelocity= new Vector3(0f,0f,0f);
        LShootFist.transform.rotation= new Quaternion(0f,0f,0f,1);
    }*/
}
