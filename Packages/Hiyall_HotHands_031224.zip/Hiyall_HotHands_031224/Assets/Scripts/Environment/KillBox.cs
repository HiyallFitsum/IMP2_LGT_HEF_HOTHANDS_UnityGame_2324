using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillBox : MonoBehaviour
{
    
    [SerializeField] CheckPoint checkPointComponent;
    void Update()
    {
    }
    void OnCollisionEnter(Collision other){
        if(other.gameObject.CompareTag("Player")||other.gameObject.CompareTag("Fist")||other.gameObject.CompareTag("MainCamera")){
            checkPointComponent.playerDead= true;
        }
        else{
            Destroy(other.gameObject);
        }
        Debug.Log("VoidColliding");
    }
}
