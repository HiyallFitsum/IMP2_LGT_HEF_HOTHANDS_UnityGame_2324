using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class Portal : MonoBehaviour
{
    [SerializeField] int NextLevel;
    [SerializeField] int enemyCount;
    [SerializeField] int enemyLayer = 6;
    private RaycastHit[] enemiesDetected;

    [SerializeField] TextMeshProUGUI EnemyCountText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        enemyCount=GameObject.FindGameObjectsWithTag("Enemy").Length;
        Debug.Log("Enemy Count: " + enemyCount);
        EnemyCountText.text = enemyCount.ToString();
    }
    void OnTriggerEnter(Collider other){
        Debug.Log(other.gameObject);
        if (other.gameObject.CompareTag("Player") && enemyCount==0){
            SceneManager.LoadScene(NextLevel);
            Debug.Log(other.gameObject);
        }
    }
}
