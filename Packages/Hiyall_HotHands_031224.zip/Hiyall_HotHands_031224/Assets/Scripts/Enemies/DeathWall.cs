using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathWall : MonoBehaviour
{
    [SerializeField] GameObject wall;
    [SerializeField] CheckPoint checkPointComponent;
    [SerializeField] float startMoveSpeed=5f;
    private float moveSpeed;
    private Vector3 startPos;
    // Start is called before the first frame update
    void Start()
    {
        moveSpeed=startMoveSpeed;
        startPos=transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += new Vector3(0f,0f,moveSpeed*Time.deltaTime);
        moveSpeed+=Time.deltaTime/2.5f;
    }
    void OnCollisionEnter(Collision other){
        if(other.gameObject.CompareTag("Player")){
            checkPointComponent.playerDead= true;
            transform.position=startPos;
            moveSpeed=startMoveSpeed;
        }
}
}
